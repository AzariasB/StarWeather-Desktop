/*
 * The MIT License
 *
 * Copyright 2017-2018 azarias.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

/*
 * File:   SensorsGraph.hpp
 * Author: azarias
 *
 * Created on 31/1/2019
 */
#ifndef SENSORSGRAPH_HPP
#define SENSORSGRAPH_HPP

#include <QWidget>
#include <QGraphicsView>
#include <QPropertyAnimation>
#include "SensorValue.hpp"


constexpr int MAX_Y = 1024;
constexpr int X_STEP = 50;
constexpr int X_VALUES = 200;
constexpr int Y_VALUES = 6;

class SensorsGraph : public QGraphicsView
{
    Q_OBJECT
    Q_PROPERTY(qreal xTranslate READ xTranslate WRITE setXTranslate)
public:
    SensorsGraph(QWidget *parent);

    void drawSensorValue(const SensorValue &value);

    void redraw();

    void setXTranslate(qreal nwValue);

    qreal xTranslate() const;

protected:

    void showEvent(QShowEvent *ev) override;

    void resizeEvent(QResizeEvent *ev) override;

private:

    QGraphicsScene m_scene;

    qreal m_xTranslate = 0;

    QPropertyAnimation m_animation = QPropertyAnimation(this, "xTranslate");

    QVector<QVector<SensorValue>> m_values = QVector<QVector<SensorValue>>(3);

    void clearOldValues(QVector<SensorValue> &values, QPolygonF &polygon, qreal left);

    void fillScene();

    void drawValues(qreal left, qreal right, qreal top, qreal bottom, qreal xStep);

    static QVector<QPen> m_pens;
};

#endif // SENSORSGRAPH_HPP
